TWILIGHT NIGHTMARE

How to Install:

Simply extract TwilightNightmare.zip into a folder.

How To Run:

Double-click TwilightNightmare.jar. Note that the content folders - Fonts, Music, Textures, Levels, Sound and lib - must remain in the same directory as the executable jar, or the game won't load properly. 

How To Start A Game:

Single player will allow you to familiarise yourself with the controls in the levels, exploring with no opponents to battle. Join Game will allow you to join a hosted game: first enter your name, then just enter the game's IP address and click Connect. Once the host is ready, they will launch the game.

To host, press New Game. Once the other players have joined the game, click Start. Choose your level, and the game is afoot!

How To Play:

The keys W, A and D control your player's movement - A is run left, D is run right, and W is jump. The mouse controls your crosshair: left mouse button will shoot towards the crosshair. You have five different weapons at your disposal: a machinegun, a flamethrower, a shotgun, a rocket launcher and grenades. The numeric keys 1-5 will select weapons, and the mouse wheel can also scroll through the weapon options.

The Objective:

Kill your opponents! Every time you kill a player (ie, you land the last hit that kills them), you score a point. The first to five points wins!


Oh, and by the way, it's not as simple as it first appears: the mind-bending levels feature areas where the laws of physics don't behave like you'd expect. Look out for areas with arrows - that means gravity's pointing in an unusual direction - or hourglasses - which means time doesn't pass at the usual rate.

One last thing: You can toggle full-screen mode on or off with Alt-Enter (or clicking the toggle on the menu screen), and if you're a filthy cheater, you can get a better idea of where your opponents are by zooming the view in and out with P and L. But you're not a filthy cheater... are you?

Note on Performance:

TwilightNightmate is a high-resolution action game, using a lot of graphic transforms and opacity effects which may affect performance on some machines. The game has been tested on a range of up-to-date Windows laptops and has been targetted performance-wise for these: whilst it will run on other machines (including those in the Linux lab) certain game effects will have a big impact on graphics refresh rates.